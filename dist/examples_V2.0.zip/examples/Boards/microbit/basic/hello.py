from microbit import display
display.scroll("hello world!")