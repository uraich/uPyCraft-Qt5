#hardware platform: FireBeetle-ESP32
#the current version does not support